-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2022 at 07:13 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `databaseproj`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `Customer_Type` varchar(50) NOT NULL,
  `Customer_First_Name` text DEFAULT NULL,
  `Customer_Last_Name` text DEFAULT NULL,
  `Business_Name` varchar(50) DEFAULT NULL,
  `Customer_Contact` varchar(50) NOT NULL,
  `Billing_Address` varchar(50) NOT NULL,
  `Billing_Barangay` varchar(50) NOT NULL,
  `Billing_City` varchar(50) NOT NULL,
  `Billing_Province` varchar(50) NOT NULL,
  `Billing_Zip_Code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `Customer_Type`, `Customer_First_Name`, `Customer_Last_Name`, `Business_Name`, `Customer_Contact`, `Billing_Address`, `Billing_Barangay`, `Billing_City`, `Billing_Province`, `Billing_Zip_Code`) VALUES
(10, 'Business', '', '', 'PUP CO.', '02192818327', 'StaMesa 1 Tr', '123 Calo', 'Manila', 'NCR', '1234'),
(11, 'Individual', 'Allen', 'Belonio', '', '01291838714', 'lot 2 street 12', 'Taytay', 'San juan', 'Rizal', '2133'),
(12, 'Individual', 'Kero', 'Taguro', '', '2019384343', 'street 15', 'Tayuman', 'Angono', 'Rizal', '4385'),
(13, 'Business', '', '', 'xyz Corp', '02913827485', 'Village 2', 'Hillsmite', 'Golden City', 'Anitpolo', '7812'),
(15, 'Business', '', '', 'Taguro co.', '01281387484', 'High lot 20', 'Martial arts', 'Palmera', 'Laguna', '6471');

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

CREATE TABLE `customer_order` (
  `Order_ID` int(11) NOT NULL,
  `Order_Date` date NOT NULL,
  `Customer_Shipping_Address` varchar(50) NOT NULL,
  `Customer_Shipping_Barangay` varchar(50) NOT NULL,
  `Customer_Shipping_City` varchar(50) NOT NULL,
  `Customer_Shipping_Province` varchar(50) NOT NULL,
  `Customer_Shipping_Zip_Code` varchar(50) NOT NULL,
  `Customer_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_order`
--

INSERT INTO `customer_order` (`Order_ID`, `Order_Date`, `Customer_Shipping_Address`, `Customer_Shipping_Barangay`, `Customer_Shipping_City`, `Customer_Shipping_Province`, `Customer_Shipping_Zip_Code`, `Customer_ID`) VALUES
(40, '2022-08-02', 'lot 2 street 12', 'Taytay', 'San juan', 'Rizal', '2133', 11),
(41, '2022-08-02', 'StaMesa 1 Tr', '123 Calo', 'Manila', 'NCR', '1234', 10),
(42, '2022-08-03', 'Earist street 12', 'Brgy 24', 'Sampaloc', 'Manila', '7264', 12),
(43, '2022-08-04', 'Village 2', 'Hillsmite', 'Golden City', 'Anitpolo', '7812', 13),
(44, '2022-09-09', 'High lot 20', 'Martial arts', 'Palmera', 'Laguna', '6471', 15),
(45, '2022-09-10', 'street 15', 'Tayuman', 'Angono', 'Rizal', '4385', 12);

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `Delivery_ID` int(11) NOT NULL,
  `Delivery_Date` date NOT NULL,
  `Courier_Name` varchar(50) NOT NULL,
  `Courier_Branch` text NOT NULL,
  `Package_ID` int(11) NOT NULL,
  `Tracking_No` varchar(50) NOT NULL,
  `Delivery_Status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`Delivery_ID`, `Delivery_Date`, `Courier_Name`, `Courier_Branch`, `Package_ID`, `Tracking_No`, `Delivery_Status`) VALUES
(21, '2022-08-12', 'J&T', 'Angono, Rizal', 32, '01029H77Y2', 'Success'),
(25, '2022-08-13', 'LBC', 'Angono, Rizal', 31, '1231H746YU', 'Success'),
(26, '2022-08-19', 'J&T', 'Angono, Rizal', 33, '127HBv1255', 'Success'),
(27, '2022-08-21', 'FlashX', 'Binangonan, Rizal', 34, '126Hb&7126', 'Lost'),
(28, '2022-09-13', 'FlashX', 'Binangonan, Rizal', 35, 'HB6271367H0', 'Success'),
(29, '2022-09-17', 'LBC', 'Antipolo, Rizal', 36, '*12873Jh', 'Failed');

-- --------------------------------------------------------

--
-- Table structure for table `failed_delivery`
--

CREATE TABLE `failed_delivery` (
  `Failed_ID` int(11) NOT NULL,
  `Delivery_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `failed_delivery`
--

INSERT INTO `failed_delivery` (`Failed_ID`, `Delivery_ID`) VALUES
(3, 29);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `Order_Detail_ID` int(11) NOT NULL,
  `Unit_Quantity` int(11) NOT NULL,
  `Total_Unit_Price` double NOT NULL,
  `Order_ID` int(11) NOT NULL,
  `Product_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`Order_Detail_ID`, `Unit_Quantity`, `Total_Unit_Price`, `Order_ID`, `Product_ID`) VALUES
(131, 2, 360, 40, 4),
(132, 2, 250, 40, 23),
(133, 8, 1200, 40, 3),
(135, 10, 1500, 43, 3),
(136, 7, 700, 43, 24),
(137, 1, 100, 43, 24),
(138, 5, 625, 43, 23),
(139, 3, 240, 42, 5),
(140, 5, 625, 42, 23),
(141, 5, 900, 42, 4),
(142, 7, 560, 41, 5),
(143, 40, 3200, 41, 5),
(146, 25, 3750, 44, 3),
(147, 25, 4500, 44, 4),
(148, 20, 2500, 45, 11),
(149, 3, 540, 45, 4);

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `Package_ID` int(11) NOT NULL,
  `No_of_Package` int(11) NOT NULL,
  `Package_Weight` varchar(50) NOT NULL,
  `Order_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`Package_ID`, `No_of_Package`, `Package_Weight`, `Order_ID`) VALUES
(31, 2, '3 kg', 40),
(32, 3, '3.5 kg', 43),
(33, 3, '2.9 kg', 42),
(34, 5, '4.1 kg', 41),
(35, 6, '7 kg', 44),
(36, 2, '2.1 kg', 45);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_ID` int(11) NOT NULL,
  `Payment_Mode` text NOT NULL,
  `Payment_Platform` text DEFAULT NULL,
  `Account_Number` varchar(50) DEFAULT NULL,
  `Payment_Status` text NOT NULL,
  `Payment_Date` date DEFAULT NULL,
  `Initial_Price` double NOT NULL,
  `Discount` double NOT NULL,
  `Fees` double NOT NULL,
  `Total_Amount` double NOT NULL,
  `Order_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_ID`, `Payment_Mode`, `Payment_Platform`, `Account_Number`, `Payment_Status`, `Payment_Date`, `Initial_Price`, `Discount`, `Fees`, `Total_Amount`, `Order_ID`) VALUES
(86, 'Online Payment', 'Gcash', '91291838831', 'Paid', '2022-08-09', 1810, 0, 50, 1860, 40),
(87, 'Online Payment', 'BDO', '0129388473', 'Paid', '2022-08-10', 2925, 0, 0, 2925, 43),
(88, 'Cash on Delivery', 'n/a', '0', 'Paid', '2022-08-19', 1765, 0, 50, 1815, 42),
(89, 'Cash on Delivery', '', '', 'Paid', '2022-08-21', 3760, 0, 100, 3860, 41),
(90, 'Online Payment', 'Gcash', '01921737431', 'Paid', '2022-09-09', 8250, 0, 200, 8450, 44),
(91, 'Cash on Delivery', '', '', 'Failed', '2022-09-17', 3040, 0, 50, 3090, 45);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `Product_ID` int(11) NOT NULL,
  `Product_Category` varchar(50) NOT NULL,
  `Product_Name` text NOT NULL,
  `Product_Price` double NOT NULL,
  `Product_Size` varchar(50) NOT NULL,
  `Product_Quantity` int(11) NOT NULL,
  `Category_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Product_ID`, `Product_Category`, `Product_Name`, `Product_Price`, `Product_Size`, `Product_Quantity`, `Category_ID`) VALUES
(3, 'Scent', 'Violet Sce', 150, '120 ml', 25, 1),
(4, 'Cosmetic', 'Blueish Coral', 180, '120 ml', 38, 2),
(5, 'Cosmetic', 'Reddish Powder', 80, '50 g', 180, 2),
(11, 'Facial', 'Toner', 125, '80 ml', 100, 9),
(21, 'Powder', 'Rosewater Powder ', 99, '10 ml', 40, 15),
(22, 'Powder', 'Goldwater Powder ', 99, '10 ml', 0, 15),
(23, 'Facial', 'Toner', 125, '80 ml', 30, 9),
(24, 'Body Wash', 'Soap Mabango', 100, '10 g', 0, 16);

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `Category_ID` int(11) NOT NULL,
  `Category_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`Category_ID`, `Category_Name`) VALUES
(1, 'Scent'),
(2, 'Cosmetic'),
(9, 'Facial'),
(15, 'Powder'),
(16, 'Body Wash');

-- --------------------------------------------------------

--
-- Table structure for table `refund`
--

CREATE TABLE `refund` (
  `Refund_ID` int(11) NOT NULL,
  `Payment_ID` int(11) NOT NULL,
  `Delivery_ID` int(11) NOT NULL,
  `Refund_Amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `refund`
--

INSERT INTO `refund` (`Refund_ID`, `Payment_ID`, `Delivery_ID`, `Refund_Amount`) VALUES
(89, 89, 27, 3860);

-- --------------------------------------------------------

--
-- Table structure for table `replacement`
--

CREATE TABLE `replacement` (
  `Replacement_ID` int(11) NOT NULL,
  `Product_ID` int(11) NOT NULL,
  `Order_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`Order_ID`),
  ADD KEY `CUS_ID_FK` (`Customer_ID`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`Delivery_ID`),
  ADD KEY `packgeID_FK` (`Package_ID`);

--
-- Indexes for table `failed_delivery`
--
ALTER TABLE `failed_delivery`
  ADD PRIMARY KEY (`Failed_ID`),
  ADD KEY `dliveryFK` (`Delivery_ID`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`Order_Detail_ID`),
  ADD KEY `OrderID_FK` (`Order_ID`),
  ADD KEY `PRoductID_FK` (`Product_ID`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`Package_ID`),
  ADD KEY `ORDERIF_FKOFPAYMENT` (`Order_ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_ID`),
  ADD KEY `OrderIDFK` (`Order_ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`Product_ID`),
  ADD KEY `CategoryID_FK` (`Category_ID`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`Category_ID`);

--
-- Indexes for table `refund`
--
ALTER TABLE `refund`
  ADD PRIMARY KEY (`Refund_ID`),
  ADD KEY `PaymentFK` (`Payment_ID`),
  ADD KEY `DeliveryID_FK` (`Delivery_ID`);

--
-- Indexes for table `replacement`
--
ALTER TABLE `replacement`
  ADD PRIMARY KEY (`Replacement_ID`),
  ADD KEY `ProdIDFK` (`Product_ID`),
  ADD KEY `OrderIDFK` (`Order_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `Order_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `Delivery_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `failed_delivery`
--
ALTER TABLE `failed_delivery`
  MODIFY `Failed_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `Order_Detail_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `Package_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `Payment_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `Product_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `Category_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `refund`
--
ALTER TABLE `refund`
  MODIFY `Refund_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `replacement`
--
ALTER TABLE `replacement`
  MODIFY `Replacement_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD CONSTRAINT `customer_order_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`);

--
-- Constraints for table `delivery`
--
ALTER TABLE `delivery`
  ADD CONSTRAINT `delivery_ibfk_1` FOREIGN KEY (`Package_ID`) REFERENCES `package` (`Package_ID`);

--
-- Constraints for table `failed_delivery`
--
ALTER TABLE `failed_delivery`
  ADD CONSTRAINT `failed_delivery_ibfk_1` FOREIGN KEY (`Delivery_ID`) REFERENCES `delivery` (`Delivery_ID`);

--
-- Constraints for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `order_detail_ibfk_1` FOREIGN KEY (`Product_ID`) REFERENCES `products` (`Product_ID`),
  ADD CONSTRAINT `order_detail_ibfk_2` FOREIGN KEY (`Order_ID`) REFERENCES `customer_order` (`Order_ID`);

--
-- Constraints for table `package`
--
ALTER TABLE `package`
  ADD CONSTRAINT `package_ibfk_1` FOREIGN KEY (`Order_ID`) REFERENCES `customer_order` (`Order_ID`),
  ADD CONSTRAINT `package_ibfk_2` FOREIGN KEY (`Order_ID`) REFERENCES `order_detail` (`Order_ID`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`Order_ID`) REFERENCES `customer_order` (`Order_ID`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`Category_ID`) REFERENCES `product_category` (`Category_ID`);

--
-- Constraints for table `refund`
--
ALTER TABLE `refund`
  ADD CONSTRAINT `refund_ibfk_1` FOREIGN KEY (`Delivery_ID`) REFERENCES `delivery` (`Delivery_ID`),
  ADD CONSTRAINT `refund_ibfk_2` FOREIGN KEY (`Payment_ID`) REFERENCES `payment` (`Payment_ID`);

--
-- Constraints for table `replacement`
--
ALTER TABLE `replacement`
  ADD CONSTRAINT `replacement_ibfk_1` FOREIGN KEY (`Product_ID`) REFERENCES `products` (`Product_ID`),
  ADD CONSTRAINT `replacement_ibfk_2` FOREIGN KEY (`Order_ID`) REFERENCES `customer_order` (`Order_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
